/**
 * Created by viddesh on 17/12/18.
 */

import React from 'react';
import { Button, Modal, Table } from 'react-bootstrap';

const tableCSS = {
    "backgroundColor": "white",
    "minHeight": "58.1vh",
    "maxHeight": "60vh"
}

let tableData = [
    //{
    //    "id": 1,
    //    "first_name": "George",
    //    "last_name": "Bluth"
    //},
    //{
    //    "id": 2,
    //    "first_name": "Janet",
    //    "last_name": "Weaver"
    //},
    //{
    //    "id": 3,
    //    "first_name": "Emma",
    //    "last_name": "Wong"
    //}
];

const thead = <tr>
    <th>#</th>
    <th>First Name</th>
    <th>Last Name</th>
</tr>;




export class MyVerticallyCenteredModal extends React.Component {


    constructor(props) {
        super(props);

        this.state = {
            loadedData: [],
            tab: []
        }
    }


    componentDidMount() {

        let table = [];

        //this.setState({
        //    loadedData:this.props.userData.data
        //});


        tableData = this.props.userData;

        for (let i in tableData) {
            let children = []
            children.push(<td>{tableData[i].id}</td>);
            children.push(<td>{tableData[i].first_name}</td>);
            children.push(<td>{tableData[i].last_name}</td>);
            table.push(<tr>{children}</tr>);
        }

        this.setState({
            tab: table
        })
    }


    render() {

        return (
            <Modal
                {...this.props}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered
            >
                <Modal.Header closeButton>
                    <Modal.Title id="contained-modal-title-vcenter">
                        Users Data
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <h5>Found some JSON data: </h5>
                    <p style={{textAlign:"center", "wordWrap": "break-word"}}>

                        { this.props.userData }
                        <hr />
                        { this.props.userData }
                    </p>
                    <hr />
                    <hr />
                    <Table style={tableCSS} striped bordered hover
                           responsive="sm">
                        <thead>
                        {thead}
                        </thead>
                        <tbody>
                        {this.state.tab}
                        </tbody>
                    </Table>

                </Modal.Body>
                <Modal.Footer>
                    <Button onClick={this.props.onHide}>Close</Button>
                </Modal.Footer>
            </Modal>
        );
    }
}