import React from 'react';
import { slide } from 'react-burger-menu'

export class Sidebar extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            loading: true
        }
    }

    render() {
        return (

            <div>
            </div>

        )
    }

}