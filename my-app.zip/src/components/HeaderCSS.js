export const headerStyle = {
    backgroundColor: "powderblue",
    height: 150,
    paddingTop: 20,
    textAlign: "center"
}