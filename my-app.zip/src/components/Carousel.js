export const carouselStyle = {
    color: "white",
    height: 100,
    paddingTop: 20,
    textAlign: "center"
}